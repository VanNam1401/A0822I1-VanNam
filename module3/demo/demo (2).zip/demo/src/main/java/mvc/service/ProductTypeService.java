package mvc.service;

import mvc.bean.ProductType;

import java.sql.SQLException;
import java.util.List;

public interface ProductTypeService extends CRUDService<ProductType> {
}
