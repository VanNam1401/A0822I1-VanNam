package mvc.repository;

import mvc.bean.ProductType;

public interface ProductTypeRepository extends CRUDRepository<ProductType> {
}
