package mvc.service;

import mvc.bean.Product;

public interface ProductService extends CRUDService<Product> {
}
