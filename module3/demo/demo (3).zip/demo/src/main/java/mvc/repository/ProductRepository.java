package mvc.repository;

import mvc.bean.Product;

public interface ProductRepository extends CRUDRepository<Product> {
}
