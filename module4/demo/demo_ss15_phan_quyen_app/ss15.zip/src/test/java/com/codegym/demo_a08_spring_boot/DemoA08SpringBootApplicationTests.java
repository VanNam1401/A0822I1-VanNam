package com.codegym.demo_a08_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoA08SpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
