package Case_study_new.libs;

import java.util.Scanner;

public interface CatchRegexInteger {
    Scanner scanner = new Scanner(System.in);
    int regexInteger();
}
