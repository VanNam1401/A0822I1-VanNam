package Case_study_new.libs;

public interface CatchRegexString {
    String regexString();
}
