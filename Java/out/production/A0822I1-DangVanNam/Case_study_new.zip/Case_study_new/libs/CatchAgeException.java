package Case_study_new.libs;

public interface CatchAgeException {
    void checkDateOfBirth(String dayOfBirth);
}
