package Case_study_new.services;

public interface EmployeeService extends Service {
}
