package Case_study_new.services;

public interface PromotionService {
    void display();
    void listGetVoucher();
}
