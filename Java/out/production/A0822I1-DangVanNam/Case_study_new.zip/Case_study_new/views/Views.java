package Case_study_new.views;


import Case_study_new.controllers.FuramaController;

public class Views {
    public static void main(String[] args) {
        new FuramaController().displayMainMenu();
    }
}
