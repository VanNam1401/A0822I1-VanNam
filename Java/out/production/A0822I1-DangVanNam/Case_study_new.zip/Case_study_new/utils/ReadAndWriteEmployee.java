package Case_study_new.utils;

import Case_study_new.models.Employee;

public interface ReadAndWriteEmployee extends ReadAndWrite<Employee> {
}
