package Case_study_new.utils;

import Case_study_new.models.Customer;

public interface ReadAndWriteCustomer extends ReadAndWrite<Customer> {
}
