package Case_study_new.utils;

import Case_study_new.models.Booking;

public interface ReadAndWriteBooking extends ReadAndWrite<Booking> {
}
